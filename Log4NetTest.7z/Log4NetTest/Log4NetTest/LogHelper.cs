﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Log4NetTest
{
    public class LogHelper
    {
        /// <summary>
        /// 日志等级
        /// </summary>
        public const int LOG_DEBUG = 0;
        public const int LOG_INFO = 1;
        public const int LOG_WARN = 2;
        public const int LOG_ERROR = 3;
        public const int LOG_FATAL = 4;

        /// <summary>
        /// 日志操作对象
        /// </summary>
        public static readonly log4net.ILog loger = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        /// <summary>
        /// 写日志接口
        /// </summary>
        /// <param name="strLog">日志信息</param>
        /// <param name="iLogLevel">日志等级</param>
        public static void writeLog(string strLog, int iLogLevel= LOG_INFO)
        {
            switch (iLogLevel)
            {
                case LOG_DEBUG:
                    loger.Debug(strLog);
                    break;

                case LOG_INFO:
                    loger.Info(strLog);
                    break;

                case LOG_WARN:
                    loger.Warn(strLog);
                    break;

                case LOG_ERROR:
                    loger.Error(strLog);
                    break;

                case LOG_FATAL:
                    loger.Fatal(strLog);
                    break;

                default:
                    loger.Info(strLog);
                    break;
            }
        }
    }
}
