﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Log4NetTest
{
    class Program
    {
        static void Main(string[] args)
        {
            LogHelper.writeLog("Debug信息", LogHelper.LOG_DEBUG);
            LogHelper.loger.Debug("Debug信息");

            LogHelper.writeLog("Info信息", LogHelper.LOG_INFO);
            LogHelper.loger.Info("Info信息");

            LogHelper.writeLog("Warn信息", LogHelper.LOG_WARN);
            LogHelper.loger.Warn("Warn信息");

            LogHelper.writeLog("Error信息", LogHelper.LOG_ERROR);
            LogHelper.loger.Error("Error信息");

            LogHelper.writeLog("Fatal信息", LogHelper.LOG_FATAL);
            LogHelper.loger.Fatal("Fatal信息");

            Console.ReadLine();
        }
    }
}
