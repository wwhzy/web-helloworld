package com.example.helloworld;

import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Rect;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

public class TouchPadView extends View
{
	private final String TAG = "TouchPadView";
	/**
	 * ���Ե�Ԫ�����������Ļ��������
	 */
	private final int TEST_UNIT_W = 60;
	/**
	 * ���Ե�Ԫ��
	 */
	private final int TEST_UNIT_H = 60;
	
	private Activity mActivity;
	
	private int mRows;
	private int mCols;
	private TestUnit[][] testUnits;
	
	/**
	 * ���캯��
	 * @param activity
	 */
	public TouchPadView(Activity activity)
	{
		super(activity);
		this.mActivity = activity;
		init();
	}
	
	/**
	 * ������ʼ��
	 */
	private int mScreenHeight;
	private int mScreenWidth;
	private void init()
	{
		DisplayMetrics displayMestrics = new DisplayMetrics();
		mActivity.getWindowManager().getDefaultDisplay().getMetrics(displayMestrics);
		mScreenHeight = displayMestrics.heightPixels;
		mScreenWidth = displayMestrics.widthPixels;
		Log.v(TAG, "mScreenHeight = " + mScreenHeight);
		Log.v(TAG, "mScreenWidth = " + mScreenWidth);
		
		mRows = mScreenHeight / TEST_UNIT_H;
		mCols = mScreenWidth / TEST_UNIT_W;
		Log.v(TAG, "mRowCount = " + mCols);
		Log.v(TAG, "mColCount = " + mRows);
		
		// ��ʼ�����Ե�Ԫ��ά����
		testUnits = new TestUnit[mRows][mCols];
		for (int i = 0; i < mRows; i++)
		{
			for (int j = 0; j < mCols; j++)
			{
				testUnits[i][j] = new TestUnit(new Rect(j * TEST_UNIT_W, i * TEST_UNIT_H, (j+1) * TEST_UNIT_W, (i+1) * TEST_UNIT_H), 
						false, Color.BLUE, Style.STROKE);
			}
		}
	}
	
	/**
	 * �ػ�UI
	 */
	protected void onDraw(Canvas canvas)
	{
		super.onDraw(canvas);
		Log.v(TAG, "onDraw running...");
		// ����
		canvas.drawColor(Color.WHITE);
		// ����
		Paint paint = new Paint();
		for (int i = 0; i < mRows; i++)
		{
			for (int j = 0; j < mCols; j++)
			{
				// ������ɫ
				paint.setColor(testUnits[i][j].getPaintColor());
				// ������ʽ
				if (testUnits[i][j].isTouch())
				{
					paint.setStyle(Paint.Style.FILL);
				}
				else
				{
					paint.setStyle(Paint.Style.STROKE);
				}
				// ����ͼ��
				canvas.drawRect(testUnits[i][j].getRect(), paint);
			}
		}
	}
	
	/**
	 * �ж����в��Ե�Ԫ�Ƿ�����ɴ���
	 * @return
	 */
	private boolean isAllRectTouched()
	{
		boolean isTouched = true;
		for (int i = 0; i < mRows; i++)
		{
			for (int j = 0; j < mCols; j++)
			{
				if (!testUnits[i][j].isTouch())
				{
					isTouched = false;
					return isTouched;
				}
			}
		}
		return isTouched;
	}
	
	/**
	 * ��Ļ�����¼���Ӧ����
	 */
	@Override
	public boolean onTouchEvent(MotionEvent event)
	{
		if (isAllRectTouched())
		{
			//mActivity.finish();
			return true;
		}
		// ����������
		int touchX = (int)event.getX();
		int touchY = (int)event.getY();
		// Խ�紦��
		if(touchX == mScreenWidth)
		{
			// touchX = touchX -1;
			touchX = touchX - TEST_UNIT_W;
		}
		if(touchY == mScreenHeight)
		{
			// touchY = touchY -1;
			touchY = touchY - TEST_UNIT_H;
		}
		// ����
		int indexX = touchX / TEST_UNIT_W;
		int indexY = touchY / TEST_UNIT_H;
		testUnits[indexY][indexX].setTouch(true);
		
		// �ػ����
		invalidate();
		return true;
	}
}
