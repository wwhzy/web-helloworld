package com.example.helloworld;

import android.app.Activity;
import android.os.Bundle;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);
        TouchPadView touchPadView = new TouchPadView(this);
        //TouchPadView1 touchPadView = new TouchPadView1(this);
        setContentView(touchPadView);
    }
}
