package com.example.helloworld;

import android.graphics.Paint.Style;
import android.graphics.Rect;

public class TestUnit {
	/**
	 * ���Ե�Ԫ��Ӧ�ľ�������
	 */
	private Rect rect;
	public Rect getRect() {
		return rect;
	}
	public void setRect(Rect rect) {
		this.rect = rect;
	}
	/**
	 * ���Ե�Ԫ��Ӧ�ľ��������Ƿ��Ѿ�Touched
	 */
	private boolean isTouch;
	public boolean isTouch() {
		return isTouch;
	}
	public void setTouch(boolean isTouch) {
		this.isTouch = isTouch;
	}
	/**
	 * ������ɫ
	 */
	private int paintColor;
	public int getPaintColor() {
		return paintColor;
	}
	public void setPaintColor(int paintColor) {
		this.paintColor = paintColor;
	}
	/**
	 * ������ʽ
	 */
	private Style paintStyle;
	public Style getPaintStyle() {
		return paintStyle;
	}
	public void setPaintStyle(Style paintStyle) {
		this.paintStyle = paintStyle;
	}
	/**
	 * ���캯��
	 * @param rect
	 * @param isTouch
	 * @param backColor
	 */
	public TestUnit(Rect rect, boolean isTouch, int backolor, Style paintStyle)
	{
		this.rect = rect;
		this.isTouch = isTouch;
		this.paintColor = backolor;
		this.paintStyle = paintStyle;
	}
	
	public TestUnit()
	{
	}
}
