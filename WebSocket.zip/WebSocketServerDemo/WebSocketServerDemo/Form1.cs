﻿using Fleck;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WebSocketServerDemo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        /// <summary>
        /// 服务地址
        /// </summary>
        public const string URL = "ws://127.0.0.1:10086";
        /// <summary>
        /// 客户端url以及其对应的Socket对象字典
        /// </summary>
        private IDictionary<string, IWebSocketConnection> dictSockets = new Dictionary<string, IWebSocketConnection>();
        /// <summary>
        /// 服务对象
        /// </summary>
        private WebSocketServer webSocketServer = null;
        private void btnServer_Click(object sender, EventArgs e)
        {
            if (webSocketServer != null)
            {
                Console.WriteLine(string.Format("{0} is running...", URL));
                return;
            }

            // 创建对象
            webSocketServer = new WebSocketServer(URL);
            // 服务出错后重启
            webSocketServer.RestartAfterListenError = true;
            // 启动服务
            webSocketServer.Start(socket =>
            {
                // 连接建立事件
                socket.OnOpen = () =>
                {
                    // 获取客户端的url
                    string clientUrl = string.Format("{0}:{1}", socket.ConnectionInfo.ClientIpAddress, socket.ConnectionInfo.ClientPort);
                    this.dictSockets.Add(clientUrl, socket);
                    Console.WriteLine(DateTime.Now.ToString() + "|服务器:和客户端:" + clientUrl + " 建立WebSock连接！");
                };

                // 连接关闭事件
                socket.OnClose = () =>
                {
                    string clientUrl = string.Format("{0}:{1}", socket.ConnectionInfo.ClientIpAddress, socket.ConnectionInfo.ClientPort);
                    //如果存在这个客户端,那么对这个socket进行移除
                    if (this.dictSockets.ContainsKey(clientUrl))
                    {
                        this.dictSockets.Remove(clientUrl);
                    }
                    Console.WriteLine(DateTime.Now.ToString() + "|服务器:和客户端:" + clientUrl + " 断开WebSock连接！");
                };

                // 接受客户端消息事件
                socket.OnMessage = message =>
                {
                    string clientUrl = string.Format("{0}:{1}", socket.ConnectionInfo.ClientIpAddress, socket.ConnectionInfo.ClientPort);
                    Console.WriteLine(DateTime.Now.ToString() + "|服务器:【收到】来客户端:" + clientUrl + "的信息：\n" + message);
                };

                // 错误事件
                socket.OnError = error =>
                {
                    string clientUrl = string.Format("{0}:{1}", socket.ConnectionInfo.ClientIpAddress, socket.ConnectionInfo.ClientPort);
                    Console.WriteLine(DateTime.Now.ToString() + "|服务器出错，客户端URL->" + clientUrl);
                };
            });

            Console.WriteLine("服务器运行在->" + URL);
        }

        /// <summary>
        /// 关闭所有客户端连接
        /// </summary>
        public void closeCientConnection()
        {
            // 关闭所有客户端连接
            foreach (var item in this.dictSockets.Values)
            {
                if (item != null)
                {
                    item.Close();
                }
            }
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            foreach (var item in dictSockets.Values)
            {
                if (item.IsAvailable == true)
                {
                    item.Send("Hello Client!");
                }
            }
        }
    }
}
