﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WebSocket4Net;

namespace WebSocketClientDemo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        /// <summary>
        /// 服务器地址
        /// </summary>
        public const string URL = "ws://127.0.0.1:10086";
        /// <summary>
        /// 客户端对象
        /// </summary>
        private WebSocket webSocket4Net = null;
        private void btnClient_Click(object sender, EventArgs e)
        {
            if (webSocket4Net != null)
            {
                Console.WriteLine("webSocket4Net is created");
                return;
            }

            // 创建对象
            webSocket4Net = new WebSocket(URL);
            // 事件回调
            webSocket4Net.Opened += webSocket4Net_Opened;
            webSocket4Net.MessageReceived += webSocket4Net_MessageReceived;
            webSocket4Net.Error += webSocket4Net_Error;
            webSocket4Net.Closed += webSocket4Net_Closed;
            // 连接服务器
            webSocket4Net.Open();
        }
        private void webSocket4Net_Opened(object sender, EventArgs e)
        {
            Console.WriteLine("Websocket is opened");
        }
        private void webSocket4Net_MessageReceived(object sender, MessageReceivedEventArgs e)
        {
            Console.WriteLine("Message received: " + e.Message);
        }
        private void webSocket4Net_Error(object sender, EventArgs e)
        {
            Console.WriteLine("onError: " + e.ToString());
        }
        private void webSocket4Net_Closed(object sender, EventArgs e)
        {
            Console.WriteLine("Websocket is closed");
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            // 发送消息
            webSocket4Net.Send("Hello Server!");
        }
    }
}
