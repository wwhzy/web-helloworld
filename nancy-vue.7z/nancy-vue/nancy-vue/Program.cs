﻿using Nancy;
using Nancy.Hosting.Self;
using nancy_vue.DAO.Model;
using nancy_vue.DAO.SqlClient;
using nancy_vue.Util;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace nancy_vue
{
    class Program
    {
        private static MySqlClient mySqlClient = null;
        public static MySqlClient getMySqlClient()
        {
            if (null == Program.mySqlClient)
            {
                List<Type> listEntity = Common.getTypesOfNamespace("nancy_vue.DAO.Model");
                Program.mySqlClient = new MySqlClient(DbType.MySql, "localhost", "SqlSugar4xTest", "root", "qwe123098", listEntity);
            }
            return Program.mySqlClient;
        }

        static void Main(string[] args)
        {
            HostConfiguration hostConfigs = new HostConfiguration()
            {
                UrlReservations = new UrlReservations() { CreateAutomatically = true }
            };

            string url = "http://localhost:10086/";
            using (var host = new NancyHost(new Uri(url), new CustomBootstrapper(), hostConfigs))
            {
                host.Start();
                Console.WriteLine("Server Starting on " + url);
                Console.WriteLine("Press Any Key to Exit...");
                Console.ReadLine();
                host.Stop();
                Console.WriteLine("Server Stoped " + url);
            }
        }

        public void testSqlClient()
        {
            List<Type> listEntity = Common.getTypesOfNamespace("nancy_vue.DAO.Model");
            MySqlClient mySqlClient = new MySqlClient(DbType.MySql, "localhost", "SqlSugar4xTest", "root", "qwe123098", listEntity);

            //增接口查询
            bool b1 = mySqlClient.insert(new User() { 
                username = "admin1",
                password = "adm1",
                createTime = DateTime.Now
            });

            // 删接口测试
            int i = mySqlClient.deleteByWhere<User>(it => it.username == "admin2" && it.password == "adm1");

            // 改接口测试
            int j = mySqlClient.updateByWhere<User>(it => new User() {
                username = "admin1",
                password = "adm1",
                createTime = DateTime.Now
            }, it => it.username == "admin3" && it.password == "adm2");

            // 查接口测试
            List<User> l = mySqlClient.queryAll<User>();
            List<User> l2 = mySqlClient.queryByWhere<User>(it => it.username == "admin1" && it.password == "adm1");
            List<User> l3 = mySqlClient.queryByWhereOrderBy<User>(it => it.username == "admin1" || it.username == "admin3", it => it.id, OrderByType.Desc);

            Console.ReadLine();
        }
    }
}
