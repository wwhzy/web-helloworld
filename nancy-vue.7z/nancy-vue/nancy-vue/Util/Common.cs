﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace nancy_vue.Util
{
    public class Common
    {
        public static List<Type> getTypesOfNamespace(string strNamespace)
        {
            List<Type> targetClasee = new List<Type>();

            var classes = Assembly.GetExecutingAssembly().GetTypes();
            foreach (var item in classes)
            {
                if (item.FullName.StartsWith(strNamespace)) 
                {
                    targetClasee.Add(item);
                }
            }

            return targetClasee;
        }
    }
}
