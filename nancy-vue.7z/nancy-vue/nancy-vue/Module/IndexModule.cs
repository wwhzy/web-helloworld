﻿using Nancy;
using Nancy.ModelBinding;
using nancy_vue.DAO.Model;
using nancy_vue.DAO.SqlClient;
using nancy_vue.FrontModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace nancy_vue.Module
{
    public class IndexModule : NancyModule
    {
        public IndexModule()
        {
            Post["/api/login"] = r =>
            {
                // 绑定FrontUser
                var frontUser = this.Bind<FrontUser>();

                MySqlClient mySqlClient = Program.getMySqlClient();
                if (mySqlClient.isUserExist(frontUser))
                {
                    return Response.AsJson(new { success = true });
                }
                else
                {
                    return Response.AsJson(new { success = false });
                }
            };

            Get["/api/users"] = r =>
            {
                MySqlClient mySqlClient = Program.getMySqlClient();
                // 查询数据表User所有记录并显示到前端
                List<User> users = mySqlClient.queryAll<User>();
                return Response.AsJson(new { success = true,  users = users});
            };
        }
    }
}
