﻿using nancy_vue.DAO.Model;
using nancy_vue.FrontModel;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace nancy_vue.DAO.SqlClient
{
    public class MySqlClient : BaseSqlClient
    {
        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="dbType">数据库类型</param>
        /// <param name="dbIP">数据库IP</param>
        /// <param name="dbName">数据库名</param>
        /// <param name="dbUser">数据库用户名</param>
        /// <param name="dbPwd">数据库密码</param>
        /// <param name="listEntity">数据库表单实体</param>
        public MySqlClient(DbType dbType, string dbIP, string dbName, string dbUser, string dbPwd, List<Type> listEntity) : 
            base (dbType, dbIP, dbName, dbUser, dbPwd, listEntity)
        {
            Console.WriteLine("Create MySqlClient Success");
        }

        /// <summary>
        /// 查询用户名是否存在
        /// </summary>
        /// <param name="frontUser"></param>
        /// <returns></returns>
        public bool isUserExist(FrontUser frontUser)
        {
            List<User> users = this.queryByWhere<User>(it => it.password == frontUser.password);
            if (users != null && users.Count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
