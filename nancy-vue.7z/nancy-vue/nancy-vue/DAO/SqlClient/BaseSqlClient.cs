﻿using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace nancy_vue.DAO.SqlClient
{
    public abstract class BaseSqlClient
    {
        #region 属性定义
        /// <summary>
        /// 数据库类型
        /// </summary>
        private DbType dbType;
        /// <summary>
        /// 数据库IP
        /// </summary>
        private string dbIP;
        /// <summary>
        /// 数据库名称
        /// </summary>
        private string dbName;
        /// <summary>
        /// 数据库用户名
        /// </summary>
        private string dbUser;
        /// <summary>
        /// 数据库密码
        /// </summary>
        private string dbPwd;
        /// <summary>
        /// 数据表实体对象，用于创建数据库表结构
        /// </summary>
        private List<Type> listEntity;
        /// <summary>
        /// 数据库连接字符串
        /// </summary>
        private string dbConnectionString;
        /// <summary>
        /// 数据库访问对象
        /// </summary>
        private SqlSugarClient sqlSugarClient = null;
        public SqlSugarClient getSqlSugarClient()
        {
            return this.sqlSugarClient;
        }
        #endregion

        #region 类初始化
        /// <summary>
        /// 构造函数，参数由子类传递
        /// </summary>
        /// <param name="dbType"></param>
        /// <param name="dbIP"></param>
        /// <param name="dbName"></param>
        /// <param name="dbUser"></param>
        /// <param name="dbPwd"></param>
        public BaseSqlClient(DbType dbType, string dbIP, string dbName, string dbUser, string dbPwd, List<Type> listEntity)
        {
            this.dbType = dbType;
            this.dbIP = dbIP;
            this.dbName = dbName;
            this.dbUser = dbUser;
            this.dbPwd = dbPwd;
            this.listEntity = listEntity;
            this.dbConnectionString = string.Format("server={0};Database={1};Uid={2};Pwd={3}", this.dbIP, this.dbName, this.dbUser, this.dbPwd);

            createSqlSugarClient();
        }

        /// <summary>
        /// 创建数据库访问对象并初始化数据库资源（自动建库+建表）
        /// </summary>
        private void createSqlSugarClient()
        {
            if (null != this.sqlSugarClient)
            {
                return;
            }

            // 创建数据库
            Console.WriteLine("#### BaseSqlClient.createSqlSugarClient Start ####");
            this.sqlSugarClient = new SqlSugarClient(new ConnectionConfig()
            {
                DbType = this.dbType,
                ConnectionString = this.dbConnectionString,
                InitKeyType = InitKeyType.Attribute,
                IsAutoCloseConnection = true,
                AopEvents = new AopEvents
                {
                    OnLogExecuting = (sql, p) =>
                    {
                        Console.WriteLine(sql);
                        Console.WriteLine(string.Join(",", p?.Select(it => it.ParameterName + ":" + it.Value)));
                    }
                }
            });
            // 建库，不存在则创建 
            this.sqlSugarClient.DbMaintenance.CreateDatabase();

            // 建表，不存在则创建
            if (this.listEntity != null && this.listEntity.Count > 0)
            {
                this.sqlSugarClient.CodeFirst.InitTables(this.listEntity.ToArray());
            }

            Console.WriteLine("#### BaseSqlClient.createSqlSugarClient End ####");
        }
        #endregion

        #region 通用增接口
        /// <summary>
        /// 增接口
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="insertObj"></param>
        /// <returns></returns>
        public bool insert<T> (T insertObj) where T : class, new()
        {
            return this.sqlSugarClient.Insertable(insertObj).UseMySql().ExecuteBlueCopy();
        }

        #endregion

        #region 通用删接口
        /// <summary>
        /// 删接口
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="expression">过滤表达式</param>
        /// <returns></returns>
        public int deleteByWhere<T> (Expression<Func<T, bool>> expression) where T : class, new()
        {
            return this.sqlSugarClient.Deleteable<T>().Where(expression).ExecuteCommand();
        }
        #endregion

        #region 通用改接口
        /// <summary>
        /// 改接口
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="columns">修改列表达式</param>
        /// <param name="expression">过滤表达式</param>
        /// <returns></returns>
        public int updateByWhere<T> (Expression<Func<T, T>> columns, Expression<Func<T, bool>> expression) where T : class, new()
        {
            return this.sqlSugarClient.Updateable<T>(columns).Where(expression).ExecuteCommand();
        }

        #endregion

        #region 通用查接口

        /// <summary>
        /// 查数据表实体所有记录，以List形式返回
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        public List<T> queryAll<T> ()
        {
            return this.sqlSugarClient.Queryable<T>().ToList();
        }

        /// <summary>
        /// 查数据表实体所有记录，排序后以List形式返回
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="expressionOrderBy"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        public List<T> queryAllOrderBy<T>(Expression<Func<T, object>> expressionOrderBy, OrderByType type = OrderByType.Asc)
        {
            return this.sqlSugarClient.Queryable<T>().OrderBy(expressionOrderBy, type).ToList();
        }

        /// <summary>
        /// 条件查询
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="expression">查询过滤表达式</param>
        /// <returns></returns>
        public List<T> queryByWhere<T> (Expression<Func<T, bool>> expression)
        {
            return this.sqlSugarClient.Queryable<T>().Where(expression).ToList();
        }

        /// <summary>
        /// 条件查询并排序
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="expression">查询过滤表达式</param>
        /// <param name="expressionOrderBy">排序列名表达式</param>
        /// <param name="type">排序方式（降序或升序）</param>
        /// <returns></returns>
        public List<T> queryByWhereOrderBy<T> (Expression<Func<T, bool>> expression, Expression<Func<T, object>> expressionOrderBy, OrderByType type = OrderByType.Asc)
        {
            return this.sqlSugarClient.Queryable<T>().Where(expression).OrderBy(expressionOrderBy, type).ToList();
        }

        #endregion
    }
}